import { Widget } from "scripting"
import { failureFrom, MonitorError, periodDates } from "./core"
import { cachedView, loadMonitor, suggestedReload } from "./service"
import { SetupWidget, WidgetView } from "./views"
import { cachedAIView, loadAI, resolveWidgetTarget } from "./ai"
import { AIWidgetView } from "./ai-views"
import { cachedFusion, fusionReload, loadFusion } from "./fusion"
import { FusionWidgetView } from "./fusion-views"

async function run() {
  try {
    const { account, kind } = resolveWidgetTarget(Widget.parameter)
    if (!account) {
      Widget.present(<SetupWidget message="请先运行脚本，添加 Cloudflare 只读账号并完成首次刷新。" />, { policy: "after", date: suggestedReload() })
      return
    }
    if (!["systemSmall", "systemMedium", "systemLarge"].includes(Widget.family)) {
      throw new MonitorError("configuration", "本项目支持桌面小号、中号、大号 Widget。请选择这三种尺寸。")
    }
    const period = Widget.family === "systemLarge" ? "7d" : "today"
    if (kind === "fusion") {
      const view = await loadFusion(account, period, { widget: true })
      const today = cachedFusion(account, "today")
      today.workers.failures = view.workers.failures
      today.ai.failures = view.ai.failures
      Widget.present(<FusionWidgetView view={view} today={today} family={Widget.family} displaySize={Widget.displaySize} />, { policy: "after", date: fusionReload(view) })
      return
    }
    if (kind === "ai") {
      const history = await loadAI(account, period, { widget: true })
      const today = cachedAIView(account, "today")
      today.failures = history.failures
      Widget.present(<AIWidgetView view={today} family={Widget.family} dates={periodDates("7d")} history={history.days} displaySize={Widget.displaySize} />, {
        policy: "after", date: suggestedReload(Date.now(), history.failures[0]),
      })
      return
    }
    const view = await loadMonitor(account, period, { widget: true })
    const today = cachedView(account, "today")
    // 大号 Widget 的历史错误同样在底部显示；今日始终使用独立日期缓存。
    today.failures = view.failures
    const dates = periodDates("7d")
    Widget.present(<WidgetView view={today} family={Widget.family} dates={dates} history={view.days} displaySize={Widget.displaySize} />, {
      policy: "after", date: suggestedReload(Date.now(), view.failures[0]),
    })
    // Widget.present 会销毁执行上下文，数据/缓存必须在它之前处理。
  } catch (error) {
    const failure = failureFrom(error)
    Widget.present(<SetupWidget message={failure.message} />, { policy: "after", date: suggestedReload(Date.now(), failure) })
  }
}
void run()
